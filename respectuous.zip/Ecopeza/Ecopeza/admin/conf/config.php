<?php
    $dbuser="root";
    $dbpass="";
    $host="localhost";
    $db="ecopeza";
    $mysqli=new mysqli($host,$dbuser, $dbpass, $db);
