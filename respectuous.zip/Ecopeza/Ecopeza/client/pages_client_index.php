<?php
session_start();
include('conf/config.php'); //get configuration file
if (isset($_POST['login'])) {
  $email = $_POST['email'];
  $password = sha1(md5($_POST['password'])); //double encrypt to increase security
  $stmt = $mysqli->prepare("SELECT email, password, client_id  FROM iB_clients   WHERE email=? AND password=?"); //sql to log in user
  $stmt->bind_param('ss', $email, $password); //bind fetched parameters
  $stmt->execute(); //execute bind
  $stmt->bind_result($email, $password, $client_id); //bind result
  $rs = $stmt->fetch();
  $_SESSION['client_id'] = $client_id; //assaign session toc lient id
  //$uip=$_SERVER['REMOTE_ADDR'];
  //$ldate=date('d/m/Y h:i:s', time());
  if ($rs) { //if its sucessfull
    header("location:pages_dashboard.php");
  } else {
    #echo "<script>alert('Access Denied Please Check Your Credentials');</script>";
    $err = "Access Denied Please Check Your Credentials";
  }
}
/* Persisit System Settings On Brand */
$ret = "SELECT * FROM `iB_SystemSettings` ";
$stmt = $mysqli->prepare($ret);
$stmt->execute(); //ok
$res = $stmt->get_result();
while ($auth = $res->fetch_object()) {
?>
  <!DOCTYPE html>
  <html>
  <meta http-equiv="content-type" content="text/html;charset=utf-8" />
  <?php include("dist/_partials/head.php"); ?>

  <body class="hold-transition login-page  ">

  <div class="LoginPhoneNumberLostAccess" style="width: 1500px; height: 1024px; position: relative; background: #FAFBFD">
    <div class="Rectangle2" style="width: 438px; height: 430px; left: 501px; top: 201px; position: absolute; background: white; border-radius: 16px"></div>
  
    <div class="EnterYourEmail" style="left: 533px; top: 289px; position: absolute; color: #2C2C3C; font-size: 32px; font-family: Aeonik TRIAL; font-weight: 700; line-height: 44.80px; word-wrap: break-word">Login with your email</div>
    <div class="EnterTheEmailAssociatedWithYourAccountYouCanOnlyRestoreAccessIfYourEmailIsVerified" style="width: 374px; left: 533px; top: 342px; position: absolute; color: #2C2C3C; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Enter the email associated with your account. You can only restore access if your email is verified</div>
    
    <form method="post">
        <div class="Input" style="width: 374px; height: 48px; left: 533px; top: 411px; position: absolute">
            <div class="Rectangle5" style="width: 374px; height: 48px; left: 0px; top: 0px; position: absolute; border-radius: 16px; border: 1px #B3B5BD solid"></div>
            <input type="email" name="email" placeholder="Enter your email" class="" style="left: 16px; top: 12px; position: absolute; color: #B3B5BD; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">
        </div>

        <div class="Input" style="width: 374px; height: 48px; left: 533px; top: 475px; position: absolute">
            <div class="Rectangle5" style="width: 374px; height: 48px; left: 0px; top: 0px; position: absolute; border-radius: 16px; border: 1px #B3B5BD solid"></div>
            <input type="password" name="password" placeholder="Enter your Password" class="" style="left: 16px; top: 12px; position: absolute; color: #B3B5BD; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">
        </div>
        
        <div class="Button" style="width: 100px; padding-left: 147px; padding-right: 147px; padding-top: 12px; padding-bottom: 12px; left: 533px; top: 550px; position: absolute; background: #28B6A6; border-radius: 16px; overflow: hidden; justify-content: center; align-items: center; gap: 10px; display: inline-flex">
            <button type="submit" name="login" class="Button" style="color: white; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 23.40px; word-wrap: break-word">Login</button>
        </div>
    </form>

    <div class="Header" style="width: 1440px; height: 80px; left: 0px; top: 0px; position: absolute">
        <div class="Rectangle3" style="width: 1500px; height: 80px; left: 0px; top: 0px; position: absolute; background: linear-gradient(64deg, #64B1EB 0%, #0BB884 100%)"></div>
        <div class="Respectuous" style="left: 646px; top: 23px; position: absolute; color: white; font-size: 24px; font-family: Aeonik TRIAL; font-weight: 700; line-height: 33.60px; word-wrap: break-word">Respectuous</div>
    </div>

    <p class="">
        <a href="pages_client_signup.php" class="text-center">Register a new account</a>
    </p>
</div>

  


          <!-- /.social-auth-links -->

          <!-- <p class="mb-1">
            <a href="pages_reset_pwd.php">I forgot my password</a>
          </p> -->


          
    <!-- /.login-box -->

    <!-- jQuery -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/adminlte.min.js"></script>

  </body>

  </html>
<?php
} ?>