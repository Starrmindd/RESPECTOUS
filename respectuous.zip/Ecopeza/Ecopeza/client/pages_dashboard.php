<?php
session_start();
include('conf/config.php');
include('conf/checklogin.php');
check_login();
$client_id = $_SESSION['client_id'];



/*
    get all dashboard analytics 
    and numeric values from distinct 
    tables
    */

//return total number of ibank clients
$result = "SELECT count(*) FROM iB_clients";
$stmt = $mysqli->prepare($result);
$stmt->execute();
$stmt->bind_result($iBClients);
$stmt->fetch();
$stmt->close();

//return total number of iBank Staffs
$result = "SELECT count(*) FROM iB_staff";
$stmt = $mysqli->prepare($result);
$stmt->execute();
$stmt->bind_result($iBStaffs);
$stmt->fetch();
$stmt->close();

//return total number of iBank Account Types
$result = "SELECT count(*) FROM iB_Acc_types";
$stmt = $mysqli->prepare($result);
$stmt->execute();
$stmt->bind_result($iB_AccsType);
$stmt->fetch();
$stmt->close();


//return total number of iBank Accounts
$result = "SELECT count(*) FROM iB_bankAccounts";
$stmt = $mysqli->prepare($result);
$stmt->execute();
$stmt->bind_result($iB_Accs);
$stmt->fetch();
$stmt->close();

//return total number of iBank Deposits
$client_id = $_SESSION['client_id'];
$result = "SELECT SUM(transaction_amt) FROM iB_Transactions WHERE  client_id = ? AND tr_type = 'Deposit' ";
$stmt = $mysqli->prepare($result);
$stmt->bind_param('i', $client_id);
$stmt->execute();
$stmt->bind_result($iB_deposits);
$stmt->fetch();
$stmt->close();

//return total number of iBank Withdrawals
$client_id = $_SESSION['client_id'];
$result = "SELECT SUM(transaction_amt) FROM iB_Transactions WHERE  client_id = ? AND tr_type = 'Withdrawal' ";
$stmt = $mysqli->prepare($result);
$stmt->bind_param('i', $client_id);
$stmt->execute();
$stmt->bind_result($iB_withdrawal);
$stmt->fetch();
$stmt->close();



//return total number of iBank Transfers
$client_id = $_SESSION['client_id'];
$result = "SELECT SUM(transaction_amt) FROM iB_Transactions WHERE  client_id = ? AND tr_type = 'Transfer' ";
$stmt = $mysqli->prepare($result);
$stmt->bind_param('i', $client_id);
$stmt->execute();
$stmt->bind_result($iB_Transfers);
$stmt->fetch();
$stmt->close();

//return total number of  iBank initial cash->balances
$client_id = $_SESSION['client_id'];
$result = "SELECT SUM(transaction_amt) FROM iB_Transactions  WHERE client_id =?";
$stmt = $mysqli->prepare($result);
$stmt->bind_param('i', $client_id);
$stmt->execute();
$stmt->bind_result($acc_amt);
$stmt->fetch();
$stmt->close();
//Get the remaining money in the accounts
$TotalBalInAccount = ($iB_deposits)  - (($iB_withdrawal) + ($iB_Transfers));


//ibank money in the wallet
$client_id = $_SESSION['client_id'];
$result = "SELECT SUM(transaction_amt) FROM iB_Transactions  WHERE client_id = ?";
$stmt = $mysqli->prepare($result);
$stmt->bind_param('i', $client_id);
$stmt->execute();
$stmt->bind_result($new_amt);
$stmt->fetch();
$stmt->close();
//Withdrawal Computations

?>


<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed "  >

  <div class="wrapper">
    <!-- Navbar -->
    <?php include("dist/_partials/nav.php"); ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include("dist/_partials/sidebar.php"); ?>
    <?php
  $client_id = $_SESSION['client_id'];
  $ret = "SELECT * FROM  iB_clients  WHERE client_id = ? ";
  $stmt = $mysqli->prepare($ret);
  $stmt->bind_param('i', $client_id);
  $stmt->execute(); //ok
  $res = $stmt->get_result();
  while ($row = $res->fetch_object()) {
    //set automatically logged in user default image if they have not updated their pics
    if ($row->profile_pic == '') {
      $profile_picture = "<img src='../admin/dist/img/user_icon.png' class=' elevation-2' alt='User Image'>
                ";
    } else {
      $profile_picture = "<img src='../admin/dist/img/$row->profile_pic' class='elevation-2' alt='User Image'>
                ";
    }



    /* Persisit System Settings On Brand */
    $ret = "SELECT * FROM `iB_SystemSettings` ";
    $stmt = $mysqli->prepare($ret);
    $stmt->execute(); //ok
    $res = $stmt->get_result();
    while ($sys = $res->fetch_object()) {
  ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper" style=" border-radius: 30px 0 0 0">
      <!-- Content Header (Page header)
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0 text-dark">Hi, <?php echo $row->name; ?></h1>
              <?php
    }
  } ?> -->
            </div><!-- /.col 
            
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">Dashboard</li>
              </ol>
            </div>--><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->

      <!-- Main content -->


      <div class="Group22" style="width: 437px; height: 189px; left: 271px; top: 112px; position: absolute">
            <div class="Rectangle1893" style="width: 437px; height: 189px; left: 0px; top: 0px; position: absolute; background: white; border-radius: 16px"></div>
            <div class="Group6" style="width: 373px; height: 125px; left: 32px; top: 32px; position: absolute">
              <div class="Button" style="width: 174px; height: 40px; left: 0px; top: 85px; position: absolute">
                <div class="Rectangle7" style="width: 174px; height: 40px; left: 0px; top: 0px; position: absolute; background: #28B6A6; border-radius: 12px"></div>
                <div class="Withdraw" style="width: 64.05px; left: 55.51px; top: 9px; position: absolute; color: white; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word"><a  href="pages_withdrawals.php" style="color:white">Withdraw</a></div>

              </div>
              <div class="Button" style="width: 174px; height: 40px; left: 199px; top: 85px; position: absolute">
                <div class="Rectangle7" style="width: 174px; height: 40px; left: 0px; top: 0px; position: absolute; border-radius: 12px; border: 1px #282A3A solid"></div>
                <div class="TopUp" style="width: 46.97px; left: 64.05px; top: 9px; position: absolute; color: #282A3A; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word"><a href="pages_topup.php" style="">Top up</a></div>
              </div>
              <div class="TotalBalance" style="left: 0px; top: 0px; position: absolute; color: #57575A; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Total balance</div>
              <div class="1205423" style="left: 0px; top: 27px; position: absolute; color: #2C2C3C; font-size: 24px; font-family: Aeonik TRIAL; font-weight: 700; line-height: 33.60px; word-wrap: break-word">$ <?php echo $TotalBalInAccount; ?></div>
            </div>
          </div>
          <div class="Group23" style="width: 437px; height: 189px; left: 732px; top: 112px; position: absolute">
            <div class="Rectangle1893" style="width: 437px; height: 189px; left: 0px; top: 0px; position: absolute; background: white; border-radius: 16px"></div>
            <div class="Group6" style="width: 373px; height: 125px; left: 32px; top: 32px; position: absolute">
              <div class="Button" style="width: 373px; height: 40px; left: 0px; top: 85px; position: absolute">
                <div class="Rectangle7" style="width: 373px; height: 40px; left: 0px; top: 0px; position: absolute; background: #28B6A6; border-radius: 12px"></div>
                <div class="Convert" style="left: 162px; top: 9px; position: absolute; color: white; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word"><a href="pages_convert_points.php" style="color: white">Convert</a></div>
              </div>
              <div class="TotalPoints" style="left: 0px; top: 0px; position: absolute; color: #57575A; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Total points</div>
              <div style="left: 0px; top: 27px; position: absolute; color: #2C2C3C; font-size: 24px; font-family: Aeonik TRIAL; font-weight: 700; line-height: 33.60px; word-wrap: break-word">o</div>
            </div>
          </div>
          <div class="Search" style="width: 343px; height: 40px; left: 271px; top: 341px; position: absolute">
    <div class="Rectangle1887" style="width: 343px; height: 40px; left: 0px; top: 0px; position: absolute; background: white; border-radius: 12px; border: 1px #F3F4F8 solid"></div>
    <div class="Search" style="left: 42px; top: 8px; position: absolute; text-align: center; color: #B3B5BD; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22px; word-wrap: break-word">Search</div>
    <div class="IconsOtherSearch" style="width: 18px; height: 18px; left: 16px; top: 10px; position: absolute">
      <div class="Vector" style="width: 14.25px; height: 14.25px; left: 1.50px; top: 1.50px; position: absolute; border-radius: 9999px; border: 1.50px #9496A1 solid"></div>
      <div class="Vector" style="width: 2.62px; height: 2.62px; left: 13.88px; top: 13.88px; position: absolute; border: 1.50px #9496A1 solid"></div>
    </div>
  </div>
  <div class="Group6" style="width: 102px; height: 40px; left: 630px; top: 341px; position: absolute">
    <div class="Rectangle20" style="width: 102px; height: 40px; left: 0px; top: 0px; position: absolute; background: white; border-radius: 8px; border: 1px #F3F4F8 solid"></div>
    <div class="LinearArrowsAltArrowDown" style="width: 24px; height: 24px; left: 70px; top: 8px; position: absolute">
    
      <div class="Vector" style=""></div>
      <i class="bx bxs-chevron-down" style="color: black"></i>
    </div>
    <div class="Date" style="left: 16px; top: 9px; position: absolute; color: #9496A1; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Date</div>
  </div>
  <div class="Group6" style="width: 126px; height: 40px; left: 748px; top: 341px; position: absolute">
    <div class="Rectangle20" style="width: 126px; height: 40px; left: 0px; top: 0px; position: absolute; background: white; border-radius: 8px; border: 1px #F3F4F8 solid"></div>
    <div class="LinearArrowsAltArrowDown" style="width: 24px; height: 24px; left: 94px; top: 8px; position: absolute">
      
    <div class="Vector" style=""></div>
    <i class="bx bxs-chevron-down" style="color: black"></i>  
  </div>
    <div class="Incomes" style="left: 16px; top: 9px; position: absolute; color: #9496A1; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Incomes</div>
  </div>

      <section class="content">
      



        <div class="container-fluid">
          
          <div class="row">
            <!--iBank Deposits 
            <div class="col-12 col-sm-6 col-md-3" >
             <div class="" style="padding: 24px; background: white; border-radius: 20px; display: flex; align-items: center; grid-gap: 24px;">
              
                <div class="info-box-content">
                  <span class="text-zinc-600 text-base leading-6 whitespace-nowrap" style="color: #333; font-size: 20px;" >Total Balance</span>
                  <span class="text-gray-800 text-2xl font-bold leading-9 whitespace-nowrap mt-2">
                    $ <?php echo $iB_deposits; ?>
                  </span>
                </div>
              </div>
            </div>-->
            <!----./ iBank Deposits-->
     


            <!--iBank Withdrwals
            <div class="col-12 col-sm-6 col-md-3">
              <div class="" style="padding: 24px; background: white; border-radius: 20px; display: flex; align-items: center; grid-gap: 24px;">
                
                <div class="info-box-content">
                  <span class="text-zinc-600 text-base leading-6 whitespace-nowrap" style="color: #333; font-size: 20px;" >Points</span>
                  <span class="text-gray-800 text-2xl font-bold leading-9 whitespace-nowrap mt-2">$ <?php echo $iB_withdrawal; ?> </span>
                </div>
              </div>
            </div>-->
            <!-- Withdrawals-->

            <!-- fix for small devices only -->
            <div class="clearfix hidden-md-up"></div>

            <!--Transfers
            <div class="col-12 col-sm-6 col-md-3">
              <div class="info-box" style="padding: 24px; background: white; border-radius: 20px; display: flex; align-items: center; grid-gap: 24px;">
                <span class=" p-1.5 bg-light rounded text-center"><i class="bx bx-shuffle" style=" width: 80px; height: 80px; border-radius: 10px; font-size: 36px; display: flex; justify-content: center; align-items: center; color: #28B6A6"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text" style="color: #333; font-size: 20px;" >Transfers</span>
                  <span class="info-box-number" style="font-size: 24px; font-weight: 600; color: #333;">$ <?php echo $iB_Transfers; ?></span>
                </div>
              </div>
            </div>-->
            <!-- /.Transfers-->

            <!--Balances
            <div class="col-12 col-sm-6 col-md-3">
              <div class="info-box" style="padding: 24px; background: white; border-radius: 20px; display: flex; align-items: center; grid-gap: 24px;">
                <span class=" p-1.5 bg-light rounded text-center"><i class="bx bxs-dollar-circle" style=" width: 80px; height: 80px; border-radius: 10px; font-size: 36px; display: flex; justify-content: center; align-items: center; color: #28B6A6;"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text" style="color: #333; font-size: 20px;" >Total Balance</span>
                  <span class="info-box-number" style="font-size: 24px; font-weight: 600; color: #333;">$ <?php echo $TotalBalInAccount; ?></span>
                </div>
              </div>
            </div>-->
            <!-- ./Balances-->
          </div>

          <div class="TableHeader" style="width: 731px; height: 26px; left: 386px; top: 421px; position: absolute">
          <div class="Points" style="left: 692px; top: 6px; position: absolute; color: #9496A1; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">Points</div>
          <div class="0000" style="left: 461px; top: 5px; position: absolute; color: #9496A1; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">Amount</div>
          <div class="DateTime" style="left: 231px; top: 0px; position: absolute; color: #9496A1; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">Date&Time</div>
          <div class="TransactionName" style="left: 0px; top: 0px; position: absolute; color: #9496A1; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">Transaction Account</div>
        </div>

        <?php
                        //Get latest transactions ;
                        $client_id = $_SESSION['client_id'];
                        $ret = "SELECT * FROM iB_Transactions WHERE  client_id = ?  ORDER BY iB_Transactions. created_at DESC ";
                        $stmt = $mysqli->prepare($ret);
                        $stmt->bind_param('i', $client_id);
                        $stmt->execute(); //ok
                        $res = $stmt->get_result();
                        $cnt = 1;
                        while ($row = $res->fetch_object()) {
                          /* Trim Transaction Timestamp to 
                            *  User Uderstandable Formart  DD-MM-YYYY :
                            */
                          $transTstamp = $row->created_at;
                          //Perfom some lil magic here
                          if ($row->tr_type == 'Deposit') {
                            $alertClass = "<span class='badge badge-success'>$row->tr_type</span>";
                          } elseif ($row->tr_type == 'Withdrawal') {
                            $alertClass = "<span class='badge badge-danger'>$row->tr_type</span>";
                          } else {
                            $alertClass = "<span class='badge badge-warning'>$row->tr_type</span>";
                          }
                        ?>

        <div class="TableCell" style="width: 1129px; height: 64px; left: 271px; top: 451px; position: absolute">
          <div class="Rectangle1888" style="width: 1129px; height: 64px; left: 0px; top: 0px; position: absolute; background: white; border-radius: 8px"></div>
          <div class="Group8" style="width: 40px; height: 40px; left: 16px; top: 12px; position: absolute">
            <div class="Ellipse2" style="width: 40px; height: 40px; left: 0px; top: 0px; position: absolute; background: #EBF7FC; border-radius: 9999px"></div>
            <div class="IconsTransactionsExpenses" style="width: 18px; height: 18px; left: 11px; top: 11px; position: absolute">
              <div class="Vector" style="width: 3px; height: 4.50px; left: 12.75px; top: 10.50px; position: absolute; border: 1.50px #57575A solid"></div>
              <div class="Vector" style="width: 15px; height: 12px; left: 1.50px; top: 3px; position: absolute; border: 1.50px #57575A solid"></div>
              <div class="Vector" style="width: 3px; height: 0px; left: 4.50px; top: 12px; position: absolute; border: 1.50px #57575A solid"></div>
              <div class="Vector" style="width: 0.38px; height: 0px; left: 9.38px; top: 12px; position: absolute; border: 1.50px #57575A solid"></div>
              <div class="Vector" style="width: 15px; height: 0px; left: 1.50px; top: 7.50px; position: absolute; border: 1.50px #57575A solid"></div>
            </div>
          </div>
          <div class="TransactionName" style="left: 115px; top: 21px; position: absolute; color: #2C2C3C; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word"><?php echo $row->account_number; ?></div>
          <div class="DateTime" style="left: 346px; top: 22px; position: absolute; color: #9496A1; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word"><?php echo date("d-M-Y h:m:s ", strtotime($transTstamp)); ?></div>
          <div class="0000" style="left: 576px; top: 20px; position: absolute; color: #2C2C3C; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 700; line-height: 22.40px; word-wrap: break-word"><?php echo $row->transaction_amt; ?></div>
          <div class="Points" style="left: 807px; top: 22px; position: absolute; color: #28B6A6; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">0</div>
        </div>
        <?php } ?>

          <!-- Main row -->
          <div class="row">
            <!-- Left col -->
            <div class="col-md-12">
              <!-- TABLE: Transactions
              <div class="card">
                <div class="card-header border-transparent">
                  <h3 class="card-title">Latest Transactions</h3>

                  <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse">
                      <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove">
                      <i class="fas fa-times"></i>
                    </button>
                  </div>
                </div> -->
                <!-- /.card-header 
                <div class="card-body p-0">
                  <div class="table-responsive">
                    <table class="table table-striped table-hover m-0">
                      <thead>
                        <tr>
                          <th>Transaction Code</th>
                          <th>Account No.</th>
                          <th>Type</th>
                          <th>Amount</th>
                          <th>Acc. Owner</th>
                          <th>Timestamp</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        //Get latest transactions ;
                        $client_id = $_SESSION['client_id'];
                        $ret = "SELECT * FROM iB_Transactions WHERE  client_id = ?  ORDER BY iB_Transactions. created_at DESC ";
                        $stmt = $mysqli->prepare($ret);
                        $stmt->bind_param('i', $client_id);
                        $stmt->execute(); //ok
                        $res = $stmt->get_result();
                        $cnt = 1;
                        while ($row = $res->fetch_object()) {
                          /* Trim Transaction Timestamp to 
                            *  User Uderstandable Formart  DD-MM-YYYY :
                            */
                          $transTstamp = $row->created_at;
                          //Perfom some lil magic here
                          if ($row->tr_type == 'Deposit') {
                            $alertClass = "<span class='badge badge-success'>$row->tr_type</span>";
                          } elseif ($row->tr_type == 'Withdrawal') {
                            $alertClass = "<span class='badge badge-danger'>$row->tr_type</span>";
                          } else {
                            $alertClass = "<span class='badge badge-warning'>$row->tr_type</span>";
                          }
                        ?>
                          <tr>
                            <td><?php echo $row->tr_code; ?></a></td>
                            <td><?php echo $row->account_number; ?></td>
                            <td><?php echo $alertClass; ?></td>
                            <td>$ <?php echo $row->transaction_amt; ?></td>
                            <td><?php echo $row->client_name; ?></td>
                            <td><?php echo date("d-M-Y h:m:s ", strtotime($transTstamp)); ?></td>
                          </tr>

                        <?php } ?>

                      </tbody>
                    </table>
                  </div>-->
                  <!-- /.table-responsive -->
                </div>
                <!-- /.card-body 
                <div class="card-footer clearfix">
                  <a href="pages_transactions_engine.php" class="btn btn-sm btn-info float-left">View All</a>
                </div>-->
                <!-- /.card-footer -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!--/. container-fluid -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->

    <!-- Main Footer -->
    <?php include("dist/_partials/footer.php"); ?>

  </div>
  <!-- ./wrapper -->

  <!-- REQUIRED SCRIPTS -->
  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- overlayScrollbars -->
  <script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.js"></script>

  <!-- OPTIONAL SCRIPTS -->
  <script src="dist/js/demo.js"></script>

  <!-- PAGE PLUGINS -->
  <!-- jQuery Mapael -->
  <script src="plugins/jquery-mousewheel/jquery.mousewheel.js"></script>
  <script src="plugins/raphael/raphael.min.js"></script>
  <script src="plugins/jquery-mapael/jquery.mapael.min.js"></script>
  <script src="plugins/jquery-mapael/maps/usa_states.min.js"></script>
  <!-- ChartJS -->
  <script src="plugins/chart.js/Chart.min.js"></script>

  <!-- PAGE SCRIPTS -->
  <script src="dist/js/pages/dashboard2.js"></script>

  <!--Load Canvas JS -->
  <script src="plugins/canvasjs.min.js"></script>
  <!--Load Few Charts-->
  <script>
    window.onload = function() {

      var Piechart = new CanvasJS.Chart("PieChart", {
        exportEnabled: false,
        animationEnabled: true,
        title: {
          text: "Accounts Per Acc Types "
        },
        legend: {
          cursor: "pointer",
          itemclick: explodePie
        },
        data: [{
          type: "pie",
          showInLegend: true,
          toolTipContent: "{name}: <strong>{y}%</strong>",
          indexLabel: "{name} - {y}%",
          dataPoints: [{
              y: <?php
                  //return total number of accounts opened under savings acc type
                  $client_id = $_SESSION['client_id'];
                  $result = "SELECT count(*) FROM iB_bankAccounts WHERE  acc_type ='Savings' AND client_id =? ";
                  $stmt = $mysqli->prepare($result);
                  $stmt->bind_param('i', $client_id);
                  $stmt->execute();
                  $stmt->bind_result($savings);
                  $stmt->fetch();
                  $stmt->close();
                  echo $savings;
                  ?>,
              name: "Savings Acc",
              exploded: true
            },

            {
              y: <?php
                  //return total number of accounts opened under  Retirement  acc type
                  $client_id  = $_SESSION['client_id'];
                  $result = "SELECT count(*) FROM iB_bankAccounts WHERE  acc_type =' Retirement' AND client_id =? ";
                  $stmt = $mysqli->prepare($result);
                  $stmt->bind_param('i', $client_id);
                  $stmt->execute();
                  $stmt->bind_result($Retirement);
                  $stmt->fetch();
                  $stmt->close();
                  echo $Retirement;
                  ?>,
              name: " Retirement Acc",
              exploded: true
            },

            {
              y: <?php
                  //return total number of accounts opened under  Recurring deposit  acc type
                  $client_id  = $_SESSION['client_id'];
                  $result = "SELECT count(*) FROM iB_bankAccounts WHERE  acc_type ='Recurring deposit' AND client_id =? ";
                  $stmt = $mysqli->prepare($result);
                  $stmt->bind_param('i', $client_id);
                  $stmt->execute();
                  $stmt->bind_result($Recurring);
                  $stmt->fetch();
                  $stmt->close();
                  echo $Recurring;
                  ?>,
              name: "Recurring deposit Acc ",
              exploded: true
            },

            {
              y: <?php
                  //return total number of accounts opened under  Fixed Deposit Account deposit  acc type
                  $client_id  = $_SESSION['client_id'];
                  $result = "SELECT count(*) FROM iB_bankAccounts WHERE  acc_type ='Fixed Deposit Account' AND client_id = ? ";
                  $stmt = $mysqli->prepare($result);
                  $stmt->bind_param('i', $client_id);
                  $stmt->execute();
                  $stmt->bind_result($Fixed);
                  $stmt->fetch();
                  $stmt->close();
                  echo $Fixed;
                  ?>,
              name: "Fixed Deposit Acc",
              exploded: true
            },

            {
              y: <?php

                  //return total number of accounts opened under  Current account deposit  acc type
                  $client_id  = $_SESSION['client_id'];
                  $result = "SELECT count(*) FROM iB_bankAccounts WHERE  acc_type ='Current account' AND client_id =? ";
                  $stmt = $mysqli->prepare($result);
                  $stmt->bind_param('i', $client_id);
                  $stmt->execute();
                  $stmt->bind_result($Current);
                  $stmt->fetch();
                  $stmt->close();
                  echo $Current;
                  ?>,
              name: "Current Acc",
              exploded: true
            }
          ]
        }]
      });

      var AccChart = new CanvasJS.Chart("AccountsPerAccountCategories", {
        exportEnabled: false,
        animationEnabled: true,
        title: {
          text: "Transactions"
        },
        legend: {
          cursor: "pointer",
          itemclick: explodePie
        },
        data: [{
          type: "pie",
          showInLegend: true,
          toolTipContent: "{name}: <strong>{y}%</strong>",
          indexLabel: "{name} - {y}%",
          dataPoints: [{
              y: <?php
                  //return total number of transactions under  Withdrawals
                  $client_id  = $_SESSION['client_id'];
                  $result = "SELECT count(*) FROM iB_Transactions WHERE  tr_type ='Withdrawal' AND client_id =? ";
                  $stmt = $mysqli->prepare($result);
                  $stmt->bind_param('i', $client_id);
                  $stmt->execute();
                  $stmt->bind_result($Withdrawals);
                  $stmt->fetch();
                  $stmt->close();
                  echo $Withdrawals;
                  ?>,
              name: "Withdrawals",
              exploded: true
            },

            {
              y: <?php
                  //return total number of transactions under  Deposits
                  $client_id  = $_SESSION['client_id'];
                  $result = "SELECT count(*) FROM iB_Transactions WHERE  tr_type ='Deposit' AND client_id =? ";
                  $stmt = $mysqli->prepare($result);
                  $stmt->bind_param('i', $client_id);
                  $stmt->execute();
                  $stmt->bind_result($Deposits);
                  $stmt->fetch();
                  $stmt->close();
                  echo $Deposits;
                  ?>,
              name: "Deposits",
              exploded: true
            },

            {
              y: <?php
                  //return total number of transactions under  Deposits
                  $client_id  = $_SESSION['client_id'];
                  $result = "SELECT count(*) FROM iB_Transactions WHERE  tr_type ='Transfer' AND client_id =? ";
                  $stmt = $mysqli->prepare($result);
                  $stmt->bind_param('i', $client_id);
                  $stmt->execute();
                  $stmt->bind_result($Transfers);
                  $stmt->fetch();
                  $stmt->close();
                  echo $Transfers;
                  ?>,
              name: "Transfers",
              exploded: true
            }

          ]
        }]
      });
      Piechart.render();
      AccChart.render();
    }

    function explodePie(e) {
      if (typeof(e.dataSeries.dataPoints[e.dataPointIndex].exploded) === "undefined" || !e.dataSeries.dataPoints[e.dataPointIndex].exploded) {
        e.dataSeries.dataPoints[e.dataPointIndex].exploded = true;
      } else {
        e.dataSeries.dataPoints[e.dataPointIndex].exploded = false;
      }
      e.chart.render();

    }
  </script>

</body>

</html>