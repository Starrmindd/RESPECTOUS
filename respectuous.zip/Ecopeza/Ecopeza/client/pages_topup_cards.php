<?php
session_start();
include('conf/config.php');
include('conf/checklogin.php');
check_login();
$client_id = $_SESSION['client_id'];
?>
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include("dist/_partials/nav.php"); ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include("dist/_partials/sidebar.php"); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper" style=" border-radius: 30px 0 0 0">
      


    <div class="Rectangle3" style="width: 438px; height: 340px; left: 501px; top: 201px; position: absolute; background: white; border-radius: 16px"></div>
    <div class="SavedCards" style="left: 533px; top: 350px; position: absolute; color: #B3B5BD; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Saved cards</div>
    <div class="AddCard" style="width: 177px; left: 533px; top: 461px; position: absolute">
      <div class="Group8" style="width: 48px; height: 48px; left: 0px; top: 0px; position: absolute">
        <div class="Ellipse2" style="width: 48px; height: 48px; left: 0px; top: 0px; position: absolute; background: #EBFCF9; border-radius: 9999px"></div>
        <div class="Add01" style="width: 24px; height: 24px; padding: 4px; left: 12px; top: 12px; position: absolute; justify-content: center; align-items: center; display: inline-flex">
          <div class="Elements" style="width: 16px; height: 16px; position: relative">
            <div class="Vector4048" style="width: 0px; height: 16px; left: 8px; top: 0px; position: absolute; border: 1.50px #6C7FF6 solid"></div>
            <div class="Vector4049" style="width: 16px; height: 0px; left: 0px; top: 8px; position: absolute; border: 1.50px #6C7FF6 solid"></div>
          </div>
        </div>
      </div>
      <div class="AddANewCard" style="left: 60px; top: 13px; position: absolute; color: #28B6A6; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 700; line-height: 22.40px; word-wrap: break-word">Add a new card</div>
    </div>
    <div class="Cell" style="width: 374px; height: 48px; left: 533px; top: 389px; position: absolute">
      <div class="Group8" style="width: 48px; height: 48px; left: 0px; top: 0px; position: absolute">
        <div class="Ellipse2" style="width: 48px; height: 48px; left: 0px; top: 0px; position: absolute; background: #EBF7FC; border-radius: 9999px"></div>
        <div class="IconsTransactionsCreditCard" style="width: 24px; height: 24px; left: 12px; top: 12px; position: absolute">
          <div class="Vector" style="width: 20px; height: 16px; left: 2px; top: 4px; position: absolute; border: 1.50px #57575A solid"></div>
          <div class="Vector" style="width: 4px; height: 0px; left: 6px; top: 16px; position: absolute; border: 1.50px #57575A solid"></div>
          <div class="Vector" style="width: 1.50px; height: 0px; left: 12.50px; top: 16px; position: absolute; border: 1.50px #57575A solid"></div>
          <div class="Vector" style="width: 20px; height: 0px; left: 2px; top: 10px; position: absolute; border: 1.50px #57575A solid"></div>
        </div>
      </div>
      <div class="Title" style="left: 60px; top: 1px; position: absolute; color: #2C2C3C; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word"><a href="pages_topup_verify.php" style="color: black">My personal Cards</a></div>
      <div class="Description" style="width: 262px; left: 60px; top: 26px; position: absolute; color: #B3B5BD; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">Card ending with 9473</div>
      <div class="IconsArrowsSimpleRight" style="width: 24px; height: 24px; left: 350px; top: 12px; position: absolute">
        <div class="Vector" style="width: 6px; height: 14px; left: 9px; top: 5px; position: absolute; border: 1.50px #2C2C3C solid"></div>
      </div>
    </div>
    <div class="TopUpBySavedCard" style="width: 374px; left: 533px; top: 273px; position: absolute; color: #2C2C3C; font-size: 32px; font-family: Aeonik TRIAL; font-weight: 700; line-height: 44.80px; word-wrap: break-word">Top up by saved card</div>
    






    

      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php include("dist/_partials/footer.php"); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- DataTables -->
  <script src="plugins/datatables/jquery.dataTables.js"></script>
  <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="dist/js/demo.js"></script>
  <!-- page script -->
  <script>
    $(function() {
      $("#example1").DataTable();
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
      });
    });
  </script>
</body>

</html>