<?php
session_start();
include('conf/config.php');
include('conf/checklogin.php');
check_login();
$client_id = $_SESSION['client_id'];
?>
<!-- Log on to codeastro.com for more projects! -->
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include("dist/_partials/nav.php"); ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include("dist/_partials/sidebar.php"); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper" style=" border-radius: 30px 0 0 0">
      


   
    <div class="Rectangle3" style="width: 438px; height: 411px; left: 501px; top: 201px; position: absolute; background: white; border-radius: 16px"></div>
    <div class="IncludingA010Fee" style="left: 646px; top: 488px; position: absolute; color: #B3B5BD; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">Including a 0.10 fee</div>
    <div class="Cell" style="width: 343px; height: 66px; left: 533px; top: 342px; position: absolute">
      <div class="Group8" style="width: 48px; height: 48px; left: 0px; top: 0px; position: absolute">
        <div class="Ellipse2" style="width: 48px; height: 48px; left: 0px; top: 0px; position: absolute; background: #EBF7FC; border-radius: 9999px"></div>
        <div class="IconsTransactionsCreditCard" style="width: 24px; height: 24px; left: 12px; top: 12px; position: absolute">
          <div class="Vector" style="width: 20px; height: 16px; left: 2px; top: 4px; position: absolute; border: 1.50px #57575A solid"></div>
          <div class="Vector" style="width: 4px; height: 0px; left: 6px; top: 16px; position: absolute; border: 1.50px #57575A solid"></div>
          <div class="Vector" style="width: 1.50px; height: 0px; left: 12.50px; top: 16px; position: absolute; border: 1.50px #57575A solid"></div>
          <div class="Vector" style="width: 20px; height: 0px; left: 2px; top: 10px; position: absolute; border: 1.50px #57575A solid"></div>
        </div>
      </div>




      <div class="Title" style="left: 60px; top: 1px; position: absolute; color: #2C2C3C; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">My personal card</div>
      <div class="Description" style="width: 262px; left: 60px; top: 26px; position: absolute; color: #B3B5BD; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">Card ending with 9473</div>
    </div>
    <div class="Input" style="width: 343px; height: 48px; left: 533px; top: 424px; position: absolute">
      <div class="Rectangle5" style="width: 374px; height: 48px; left: 0px; top: 0px; position: absolute; border-radius: 16px; border: 1px #B3B5BD solid"></div>
      <div class="Placeholder" style="left: 16px; top: 12px; position: absolute; color: #B3B5BD; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Confirm security code</div>
    </div>
    <div class="Button" style="width: 374px; padding-left: 147px; padding-right: 147px; padding-top: 12px; padding-bottom: 12px; left: 533px; top: 532px; position: absolute; background: #28B6A6; border-radius: 16px; overflow: hidden; justify-content: center; align-items: center; gap: 10px; display: inline-flex">
      <div class="Button" style="color: white; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 23.40px; word-wrap: break-word">Pay $100</div>
    </div>
    <div class="VerificationCode" style="width: 374px; left: 533px; top: 273px; position: absolute; color: #2C2C3C; font-size: 32px; font-family: Aeonik TRIAL; font-weight: 700; line-height: 44.80px; word-wrap: break-word">Verification code</div>
    
    

      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php include("dist/_partials/footer.php"); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- DataTables -->
  <script src="plugins/datatables/jquery.dataTables.js"></script>
  <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="dist/js/demo.js"></script>
  <!-- page script -->
  <script>
    $(function() {
      $("#example1").DataTable();
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
      });
    });
  </script>
</body>

</html>