<?php
session_start();
include('conf/config.php');
include('conf/checklogin.php');
check_login();
$client_id = $_SESSION['client_id'];
?>
<!-- Log on to codeastro.com for more projects! -->
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include("dist/_partials/nav.php"); ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include("dist/_partials/sidebar.php"); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper" style=" border-radius: 30px 0 0 0">
      


    <div class="Rectangle3 w-[438px] h-[411px] left-[501px] top-[201px] absolute bg-white rounded-2xl"></div>
    <div class="IncludingA010Fee left-[646px] top-[488px] absolute text-gray-400 text-sm font-normal font-['Aeonik TRIAL'] leading-tight">Including a 0.10 fee</div>
    <div class="Cell w-[374px] h-[66px] left-[533px] top-[342px] absolute">
        <div class="Group8 w-12 h-12 left-0 top-0 absolute">
            <div class="Ellipse2 w-12 h-12 left-0 top-0 absolute bg-blue-50 rounded-full"></div>
            <div class="IconsTransactionsCreditCard w-6 h-6 left-[12px] top-[12px] absolute"></div>
        </div>
        <div class="AccountBalance left-[60px] top-[1px] absolute text-gray-800 text-base font-normal font-['Aeonik TRIAL'] leading-snug">Account balance</div>
        <div class="1205423 w-[262px] left-[60px] top-[26px] absolute text-gray-400 text-sm font-normal font-['Aeonik TRIAL'] leading-tight">$20</div>
    </div>
    <div class="Input w-[343px] h-12 left-[533px] top-[424px] absolute">
        <div class="Rectangle5 w-[374px] h-12 left-0 top-0 absolute rounded-2xl border border-gray-400"></div>
        <div class="ConfirmSecurityCode left-[16px] top-[12px] absolute text-gray-400 text-base font-normal font-['Aeonik TRIAL'] leading-snug">Confirm security code</div>
    </div>
    <div class="Button w-[374px] px-[147px] py-3 left-[533px] top-[532px] absolute bg-teal-500 rounded-2xl justify-center items-center gap-2.5 inline-flex">
        <div class="Button text-white text-base font-normal font-['Aeonik TRIAL'] leading-normal">Convert points</div>
    </div>
    <div class="VerificationCode w-[374px] left-[533px] top-[273px] absolute text-gray-800 text-[32px] font-bold font-['Aeonik TRIAL'] leading-[44.80px]">Verification code</div>
    <div class="IconsArrowsRoundedLeft w-6 h-6 left-[533px] top-[233px] absolute">
        <div class="Vector w-5 h-5 left-[2px] top-[2px] absolute rounded-full border border-gray-800"></div>
    </div>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php include("dist/_partials/footer.php"); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- DataTables -->
  <script src="plugins/datatables/jquery.dataTables.js"></script>
  <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="dist/js/demo.js"></script>
  <!-- page script -->
  <script>
    $(function() {
      $("#example1").DataTable();
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
      });
    });
  </script>
</body>

</html>