<?php
session_start();
include('conf/config.php');
include('conf/checklogin.php');
check_login();
$client_id = $_SESSION['client_id'];
?>
<!-- Log on to codeastro.com for more projects! -->
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include("dist/_partials/nav.php"); ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include("dist/_partials/sidebar.php"); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper" style=" border-radius: 30px 0 0 0">
      


    <div class="Rectangle3" style="width: 438px; height: 298px; left: 501px; top: 201px; position: absolute; background: white; border-radius: 16px"></div>
    <div class="ConvertPoints" style="width: 222px; left: 533px; top: 233px; position: absolute; color: #2C2C3C; font-size: 32px; font-family: Aeonik TRIAL; font-weight: 700; line-height: 44.80px; word-wrap: break-word">Convert points</div>
  
    <div class="Input" style="width: 374px; height: 48px; left: 533px; top: 355px; position: absolute">
            <div class="Rectangle5" style="width: 374px; height: 48px; left: 0px; top: 0px; position: absolute; border-radius: 16px; border: 1px #B3B5BD solid"></div>
            <input type="points"  placeholder="Enter The amount" class="" style="left: 16px; top: 12px; position: absolute; color: #B3B5BD; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">
        </div>


   

    <div class="EnterTheAmountYouWantToConvertToYourBalance" style="width: 374px; left: 533px; top: 286px; position: absolute; color: #2C2C3C; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Enter the amount you want to convert to your balance</div>

  



    <div class="Button" style="width: 250px; padding-left: 147px; padding-right: 147px; padding-top: 12px; padding-bottom: 12px; left: 533px; top: 419px; position: absolute; background: #28B6A6; border-radius: 16px; overflow: hidden; justify-content: center; align-items: center; gap: 10px; display: inline-flex">
      <div class="Button" style="color: white; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 23.40px; word-wrap: break-word"><a href="pages_convert_confirm.php" style="color: white">Continue</a></div>
    </div>

      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php include("dist/_partials/footer.php"); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- DataTables -->
  <script src="plugins/datatables/jquery.dataTables.js"></script>
  <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="dist/js/demo.js"></script>
  <!-- page script -->
  <script>
    $(function() {
      $("#example1").DataTable();
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
      });
    });
  </script>
</body>

</html>