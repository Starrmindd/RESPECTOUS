<?php
session_start();
include('conf/config.php');
include('conf/checklogin.php');
check_login();
$client_id = $_SESSION['client_id'];
?>
<!-- Log on to codeastro.com for more projects! -->
<!DOCTYPE html>
<html>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<?php include("dist/_partials/head.php"); ?>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
  <div class="wrapper">
    <!-- Navbar -->
    <?php include("dist/_partials/nav.php"); ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <?php include("dist/_partials/sidebar.php"); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper" style=" border-radius: 30px 0 0 0">
      <!-- Content Header (Page header) -->
      <div class="Search" style="width: 343px; height: 40px; left: 271px; top: 50px; position: absolute">
          <div class="Rectangle1887" style="width: 343px; height: 40px; left: 0px; top: 0px; position: absolute; background: white; border-radius: 12px; border: 1px #F3F4F8 solid"></div>
          <div class="Search" style="left: 42px; top: 8px; position: absolute; text-align: center; color: #B3B5BD; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22px; word-wrap: break-word">Search</div>
          <div class="IconsOtherSearch" style="width: 18px; height: 18px; left: 16px; top: 10px; position: absolute">
            <div class="Vector" style="width: 14.25px; height: 14.25px; left: 1.50px; top: 1.50px; position: absolute; border-radius: 9999px; border: 1.50px #9496A1 solid"></div>
            <div class="Vector" style="width: 2.62px; height: 2.62px; left: 13.88px; top: 13.88px; position: absolute; border: 1.50px #9496A1 solid"></div>
          </div>
        </div>
        <div class="ProjectCard" style="width: 360px; height: 152px; left: 271px; top: 150px; position: absolute">
          <div class="Rectangle1889" style="width: 360px; height: 152px; left: 0px; top: 0px; position: absolute; background: white; border-radius: 16px"></div>
          <div class="AStrongConnectingThreadBetweenThoseInNeedOfHelpAndThoseWhoWantToHelp" style="width: 328px; left: 16px; top: 72px; position: absolute; color: #B3B5BD; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">A strong connecting thread between those in need of help and those who want to help</div>
          <div class="FamilyHearth" style="left: 80px; top: 28px; position: absolute; color: #2C2C3C; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Family hearth</div>
          <img class="Ellipse2" style="width: 48px; height: 48px; left: 16px; top: 16px; position: absolute; border-radius: 9999px" src="dist/img/1figma.png" />
        </div>
        <div class="ProjectCard" style="width: 360px; height: 152px; left: 271px; top: 360px; position: absolute">
          <div class="Rectangle1889" style="width: 360px; height: 152px; left: 0px; top: 0px; position: absolute; background: white; border-radius: 16px"></div>
          <div class="WeProvideAssistanceToHomelessAndDomesticAnimalsPlaceCatsAndDogsInFamilies" style="width: 328px; left: 16px; top: 72px; position: absolute; color: #9496A1; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">We provide assistance to homeless and domestic animals, place cats and dogs in families</div>
          <div class="PickAFriend" style="left: 80px; top: 28px; position: absolute; color: #282A3A; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Pick a friend</div>
          <img class="Ellipse2" style="width: 48px; height: 48px; left: 16px; top: 16px; position: absolute; border-radius: 9999px" src="dist/img/4figma.png" />
        </div>
        <div class="ProjectCard" style="width: 360px; height: 152px; left: 655px; top: 150px; position: absolute">
          <div class="Rectangle1889" style="width: 360px; height: 152px; left: 0px; top: 0px; position: absolute; background: white; border-radius: 16px"></div>
          <div class="CreatesAndSupportsProgramsThatImproveTheLivesAndHealthOfSeriouslyIllChildren" style="width: 328px; left: 16px; top: 72px; position: absolute; color: #9496A1; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">Creates and supports programs that improve the lives and health of seriously ill children</div>
          <div class="FamilyTogether" style="left: 80px; top: 28px; position: absolute; color: #282A3A; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Family together</div>
          <img class="Ellipse2" style="width: 48px; height: 48px; left: 16px; top: 16px; position: absolute; border-radius: 9999px" src="dist/img/2figma.jpeg" />
        </div>
        <div class="ProjectCard" style="width: 360px; height: 152px; left: 655px; top: 360px; position: absolute">
          <div class="Rectangle1889" style="width: 360px; height: 152px; left: 0px; top: 0px; position: absolute; background: white; border-radius: 16px"></div>
          <div class="WeProvideAssistanceToHomelessAndDomesticAnimalsPlaceCatsAndDogsInFamilies" style="width: 328px; left: 16px; top: 72px; position: absolute; color: #9496A1; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">We provide assistance to homeless and domestic animals, place cats and dogs in families</div>
          <div class="AtKids" style="left: 80px; top: 28px; position: absolute; color: #282A3A; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Сat kids</div>
          <img class="Ellipse2" style="width: 48px; height: 48px; left: 16px; top: 16px; position: absolute; border-radius: 9999px" src="dist/img/5figma.jpeg" />
        </div>
        <div class="ProjectCard" style="width: 360px; height: 152px; left: 1039px; top: 150px; position: absolute">
          <div class="Rectangle1889" style="width: 360px; height: 152px; left: 0px; top: 0px; position: absolute; background: white; border-radius: 16px"></div>
          <div class="AnimalCharityFoundation" style="width: 328px; left: 16px; top: 72px; position: absolute; color: #9496A1; font-size: 14px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 19.60px; word-wrap: break-word">Animal charity foundation</div>
          <div class="GoodTogether" style="left: 80px; top: 28px; position: absolute; color: #282A3A; font-size: 16px; font-family: Aeonik TRIAL; font-weight: 400; line-height: 22.40px; word-wrap: break-word">Good together</div>
          <img class="Ellipse2" style="width: 48px; height: 48px; left: 16px; top: 16px; position: absolute; border-radius: 9999px" src="dist/img/3figma.png" />
        </div>
      </div>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php include("dist/_partials/footer.php"); ?>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
  </div>
  <!-- ./wrapper -->

  <!-- jQuery -->
  <script src="plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- DataTables -->
  <script src="plugins/datatables/jquery.dataTables.js"></script>
  <script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
  <!-- AdminLTE App -->
  <script src="dist/js/adminlte.min.js"></script>
  <!-- AdminLTE for demo purposes -->
  <script src="dist/js/demo.js"></script>
  <!-- page script -->
  <script>
    $(function() {
      $("#example1").DataTable();
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
      });
    });
  </script>
</body>

</html>